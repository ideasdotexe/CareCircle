// CareCircle — Find caregiver flow (owner side)
// Search → results → caregiver profile → send request

const fc = window.tokens;

// ─── Sample data ────────────────────────────────────────
const caregiverDirectory = [
  {
    id: 'priya-mehta',
    name: 'Priya Mehta',
    initials: 'PM',
    photoTone: ['#C66E4E', '#B05E40'],
    title: 'Personal Support Worker',
    yearsExp: 9,
    verified: true,
    city: 'Toronto',
    region: 'East York',
    province: 'ON',
    country: 'Canada',
    rate: '$28/hr',
    rating: 4.9,
    reviewCount: 142,
    languages: ['English', 'Hindi', 'Punjabi'],
    specialties: ['Dementia', 'Post-op', 'Diabetes care'],
    available: 'Weekdays · evenings',
    bio: 'Nine years of in-home support across the GTA, with a special focus on dementia and post-surgical recovery. Calm, reliable, gentle with anxious clients.',
    reviews: [
      { who: 'Anita L.', rel: 'Daughter · Etobicoke', when: '2 weeks ago', stars: 5, text: 'Priya cared for my mum after her hip surgery. She arrived on time every shift, kept clear notes, and Mum genuinely looked forward to seeing her.' },
      { who: 'Karim S.', rel: 'Son · North York',     when: '1 month ago', stars: 5, text: 'Patient and gentle with my father who has early dementia. She follows his routine without making him feel managed.' },
      { who: 'Hannah B.', rel: 'Spouse · Scarborough', when: '3 months ago', stars: 4, text: 'Excellent with medications and BP tracking. We needed a slightly different schedule than she could offer, but skill-wise: top notch.' },
    ],
  },
  {
    id: 'james-okoye',
    name: 'James Okoye',
    initials: 'JO',
    photoTone: ['#3F5D54', '#2E4942'],
    title: 'Registered Practical Nurse',
    yearsExp: 12,
    verified: true,
    city: 'Toronto',
    region: 'Downtown',
    province: 'ON',
    country: 'Canada',
    rate: '$36/hr',
    rating: 4.8,
    reviewCount: 87,
    languages: ['English', 'French'],
    specialties: ['Cardiac care', 'Wound care', 'Medication administration'],
    available: 'Mornings · weekends',
    bio: 'RPN with hospital cardiology experience now focusing on in-home support for seniors with complex medication routines.',
    reviews: [
      { who: 'Mei C.',    rel: 'Daughter · Mississauga', when: '3 weeks ago', stars: 5, text: 'James caught a medication interaction I had missed. Thorough, professional, kind.' },
    ],
  },
  {
    id: 'anika-shah',
    name: 'Anika Shah',
    initials: 'AS',
    photoTone: ['#A8B5A0', '#7E8B77'],
    title: 'Personal Support Worker',
    yearsExp: 5,
    verified: true,
    city: 'Brampton',
    region: 'Bramalea',
    province: 'ON',
    country: 'Canada',
    rate: '$26/hr',
    rating: 4.7,
    reviewCount: 38,
    languages: ['English', 'Gujarati'],
    specialties: ['Companion care', 'Mobility'],
    available: 'Flexible',
    bio: 'Warm, attentive support for daily routines — meals, walks, light housework, and lots of conversation.',
    reviews: [
      { who: 'Diane P.',  rel: 'Wife · Brampton', when: '2 months ago', stars: 5, text: 'Anika brings sunshine into the house. My husband talks more when she\'s here.' },
    ],
  },
  {
    id: 'farah-ahmed',
    name: 'Farah Ahmed',
    initials: 'FA',
    photoTone: ['#7A5A3F', '#5C4327'],
    title: 'PSW · Live-in available',
    yearsExp: 14,
    verified: true,
    city: 'Markham',
    region: 'Unionville',
    province: 'ON',
    country: 'Canada',
    rate: '$30/hr',
    rating: 4.95,
    reviewCount: 211,
    languages: ['English', 'Arabic', 'Urdu'],
    specialties: ['Live-in', 'Dementia', 'Hospice support'],
    available: 'Live-in · 3-day rotations',
    bio: 'Lead caregiver with over 14 years across Toronto and York Region. Live-in capable. Discreet, dignified, respectful of family rhythms.',
    reviews: [
      { who: 'Ravi P.',   rel: 'Son · Markham', when: '5 days ago', stars: 5, text: 'Farah took over my mother\'s overnight care last spring. We sleep again. We trust her with everything.' },
    ],
  },
  {
    id: 'luc-tremblay',
    name: 'Luc Tremblay',
    initials: 'LT',
    photoTone: ['#1F3D38', '#15302C'],
    title: 'PSW',
    yearsExp: 3,
    verified: false,
    city: 'Ottawa',
    region: 'Vanier',
    province: 'ON',
    country: 'Canada',
    rate: '$24/hr',
    rating: 4.5,
    reviewCount: 11,
    languages: ['English', 'French'],
    specialties: ['Companion care', 'Light housework'],
    available: 'Weekends',
    bio: 'PSW certificate from Algonquin College. Currently building experience with senior clients.',
    reviews: [],
  },
];

// ─── Icons ──────────────────────────────────────────────
const FCI = {
  back: (c = fc.ink) => (<svg width="9" height="16" viewBox="0 0 9 16"><path d="M8 1L1 8l7 7" stroke={c} strokeWidth="1.6" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>),
  search: (c = fc.muted) => (<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="7" cy="7" r="5" stroke={c} strokeWidth="1.5"/><path d="M11 11l4 4" stroke={c} strokeWidth="1.5" strokeLinecap="round"/></svg>),
  filter: (c = fc.muted) => (<svg width="14" height="12" viewBox="0 0 14 12" fill="none"><path d="M1 2h12M3 6h8M5 10h4" stroke={c} strokeWidth="1.5" strokeLinecap="round"/></svg>),
  pin: (c = fc.muted) => (<svg width="11" height="13" viewBox="0 0 11 13" fill="none"><path d="M5.5 1a4 4 0 014 4c0 3-4 7-4 7s-4-4-4-7a4 4 0 014-4z" stroke={c} strokeWidth="1.3"/><circle cx="5.5" cy="5" r="1.5" stroke={c} strokeWidth="1.3"/></svg>),
  star: (c = '#D49542', filled = true) => (<svg width="11" height="11" viewBox="0 0 11 11"><path d="M5.5 1l1.4 2.8 3.1.5-2.3 2.2.5 3.1L5.5 8.1 2.8 9.6l.5-3.1L1 4.3l3.1-.5L5.5 1z" fill={filled ? c : 'none'} stroke={c} strokeWidth="1"/></svg>),
  verified: (c = '#fff') => (<svg width="11" height="11" viewBox="0 0 11 11"><path d="M5.5 1l1.2.8 1.4-.2.4 1.4 1.2.9-.6 1.3.4 1.4-1.3.4-.7 1.3-1.4-.4L5.5 8l-1-1-1.4.4-.7-1.3-1.3-.4.4-1.4L1 3l1.2-.9.4-1.4 1.4.2L5.5 1z" fill={c}/><path d="M3.5 5.5l1.5 1.5 3-3" stroke={fc.forest} strokeWidth="1.2" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>),
  send: (c = '#fff') => (<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M1 7h12m0 0L8 2m5 5L8 12" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>),
  msg: (c = fc.forest) => (<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M1 3a2 2 0 012-2h8a2 2 0 012 2v5a2 2 0 01-2 2H6l-3 3v-3H3a2 2 0 01-2-2V3z" stroke={c} strokeWidth="1.4" strokeLinejoin="round"/></svg>),
  bookmark: (c = fc.muted) => (<svg width="11" height="14" viewBox="0 0 11 14" fill="none"><path d="M1 1h9v12L5.5 10 1 13V1z" stroke={c} strokeWidth="1.3" strokeLinejoin="round"/></svg>),
  chevR: (c = fc.muted) => (<svg width="7" height="12" viewBox="0 0 7 12" fill="none"><path d="M1 1l5 5-5 5" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>),
  close: (c = fc.ink) => (<svg width="12" height="12" viewBox="0 0 12 12"><path d="M2 2l8 8M10 2L2 10" stroke={c} strokeWidth="1.6" strokeLinecap="round"/></svg>),
};

// ─── Small atoms ────────────────────────────────────────
function PhotoTile({ tones, initials, size = 56, radius = 14 }) {
  const [a, b] = tones;
  return (
    <div style={{
      width: size, height: size, borderRadius: radius, flexShrink: 0,
      background: `repeating-linear-gradient(135deg, ${a} 0 6px, ${b} 6px 12px)`,
      display: 'flex', alignItems: 'flex-end', justifyContent: 'flex-start',
      padding: 6, position: 'relative', overflow: 'hidden',
      border: '1px solid rgba(255,255,255,0.15)',
    }}>
      <div style={{
        fontFamily: fc.serif, fontSize: size * 0.32, color: '#fff',
        fontWeight: 500, letterSpacing: -0.5, lineHeight: 1,
        textShadow: '0 1px 2px rgba(0,0,0,0.15)',
      }}>{initials}</div>
      <svg width={size * 0.7} height={size * 0.7} viewBox="0 0 50 50"
           style={{ position: 'absolute', right: -size * 0.15, top: -size * 0.15, opacity: 0.2 }}>
        <circle cx="25" cy="25" r="22" stroke="#fff" strokeWidth="1" fill="none"/>
        <circle cx="25" cy="25" r="14" stroke="#fff" strokeWidth="1" fill="none"/>
      </svg>
    </div>
  );
}

function VerifiedTag({ small }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: small ? '2px 6px' : '3px 8px',
      borderRadius: 99, background: fc.forest, color: '#fff',
      fontSize: small ? 9 : 10, fontWeight: 700, letterSpacing: 0.4,
      textTransform: 'uppercase',
    }}>{FCI.verified('#fff')} Verified pro</span>
  );
}

function Stars({ rating, size = 11 }) {
  const full = Math.floor(rating);
  return (
    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 1 }}>
      {[0,1,2,3,4].map(i => (
        <svg key={i} width={size} height={size} viewBox="0 0 11 11">
          <path d="M5.5 1l1.4 2.8 3.1.5-2.3 2.2.5 3.1L5.5 8.1 2.8 9.6l.5-3.1L1 4.3l3.1-.5L5.5 1z"
            fill={i < full ? '#D49542' : 'none'} stroke="#D49542" strokeWidth="1"/>
        </svg>
      ))}
    </div>
  );
}

// =========================================================
// SCREEN 1 — Search caregivers
// =========================================================
function FindCaregiverSearch({ onBack, onOpenProfile }) {
  const [q, setQ] = React.useState('');
  const [tag, setTag] = React.useState('All');

  const tagSet = ['All', 'Toronto', 'PSW', 'Dementia', 'Live-in', 'French'];

  const matchTag = (c) => {
    if (tag === 'All') return true;
    if (tag === 'PSW')      return /psw/i.test(c.title);
    if (tag === 'Dementia') return c.specialties.some(s => /dementia/i.test(s));
    if (tag === 'Live-in')  return c.specialties.some(s => /live/i.test(s)) || /live/i.test(c.title);
    if (tag === 'French')   return c.languages.includes('French');
    return c.city === tag;
  };

  const matchQ = (c) => {
    if (!q) return true;
    const s = q.toLowerCase();
    return (
      c.name.toLowerCase().includes(s) ||
      c.city.toLowerCase().includes(s) ||
      c.province.toLowerCase().includes(s) ||
      c.region.toLowerCase().includes(s) ||
      c.title.toLowerCase().includes(s) ||
      c.specialties.join(' ').toLowerCase().includes(s) ||
      c.languages.join(' ').toLowerCase().includes(s) ||
      c.name.toLowerCase().replace(/\s+/g, '.') + '@example.com' === s
    );
  };

  const results = caregiverDirectory.filter(c => matchTag(c) && matchQ(c));

  return (
    <div style={{
      width: '100%', height: '100%', background: fc.cream,
      fontFamily: fc.sans, color: fc.ink,
      display: 'flex', flexDirection: 'column', paddingTop: 56,
    }}>
      {/* top bar */}
      <div style={{
        padding: '14px 24px 0',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div onClick={onBack} style={{
          width: 36, height: 36, borderRadius: 12,
          background: '#fff', border: `1px solid ${fc.line}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer',
        }}>{FCI.back()}</div>
        <div style={{
          fontFamily: fc.serif, fontSize: 16, color: fc.forestDeep,
          fontWeight: 500, letterSpacing: -0.2,
        }}>Find a caregiver</div>
        <div style={{
          width: 36, height: 36, borderRadius: 12,
          background: '#fff', border: `1px solid ${fc.line}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{FCI.filter()}</div>
      </div>

      {/* heading */}
      <div style={{ padding: '20px 24px 0' }}>
        <div style={{
          fontFamily: fc.serif, fontSize: 26, lineHeight: '30px',
          letterSpacing: -0.6, color: fc.forestDeep, fontWeight: 400,
        }}>The right hands,<br />close to home.</div>
        <div style={{ marginTop: 8, fontSize: 13, color: fc.muted, lineHeight: '18px', maxWidth: 320 }}>
          Verified professional caregivers across Canada. Search by name, email, or city.
        </div>
      </div>

      {/* search field */}
      <div style={{ padding: '20px 20px 0' }}>
        <div style={{
          height: 50, background: '#fff', border: `1px solid ${fc.line}`,
          borderRadius: 14, padding: '0 14px',
          display: 'flex', alignItems: 'center', gap: 10,
        }}>
          {FCI.search()}
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Name, email, city, or specialty"
            style={{
              flex: 1, border: 'none', outline: 'none', background: 'transparent',
              fontFamily: fc.sans, fontSize: 14.5, color: fc.ink,
              letterSpacing: -0.15,
            }}
          />
          {q && (
            <div onClick={() => setQ('')} style={{
              width: 22, height: 22, borderRadius: 99,
              background: fc.line, color: '#fff',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer',
            }}>{FCI.close('#fff')}</div>
          )}
        </div>
      </div>

      {/* filter chips */}
      <div style={{
        padding: '12px 20px 0',
        display: 'flex', gap: 7, overflowX: 'auto',
      }}>
        {tagSet.map(t => {
          const active = tag === t;
          return (
            <button key={t} onClick={() => setTag(t)} style={{
              flexShrink: 0, height: 32, padding: '0 14px', borderRadius: 99,
              cursor: 'pointer',
              border: `1px solid ${active ? fc.forestDeep : fc.line}`,
              background: active ? fc.forestDeep : '#fff',
              color: active ? '#fff' : fc.ink,
              fontFamily: fc.sans, fontSize: 12.5, fontWeight: 500,
              letterSpacing: -0.1,
              display: 'flex', alignItems: 'center', gap: 6,
            }}>
              {t === 'Toronto' && FCI.pin(active ? '#fff' : fc.muted)}
              {t}
            </button>
          );
        })}
      </div>

      {/* results meta */}
      <div style={{
        padding: '18px 24px 8px',
        display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
      }}>
        <div style={{
          fontFamily: fc.serif, fontSize: 15, color: fc.forestDeep,
          fontWeight: 500, letterSpacing: -0.2,
        }}>
          {results.length} {results.length === 1 ? 'match' : 'matches'}
          {q && <span style={{ color: fc.muted, fontWeight: 400 }}> for "{q}"</span>}
        </div>
        <div style={{ fontSize: 11, color: fc.muted, letterSpacing: 0.3 }}>
          Sorted by rating
        </div>
      </div>

      {/* results */}
      <div style={{ flex: 1, overflow: 'auto', padding: '0 20px 30px' }}>
        {results.map((c, i) => (
          <SearchResultCard key={c.id} c={c} onClick={() => onOpenProfile(c)} />
        ))}
        {results.length === 0 && (
          <div style={{
            background: '#fff', borderRadius: 16, border: `1px dashed ${fc.line}`,
            padding: 24, textAlign: 'center',
          }}>
            <div style={{
              fontFamily: fc.serif, fontSize: 15, color: fc.forestDeep,
              fontWeight: 500, letterSpacing: -0.2,
            }}>No matches yet</div>
            <div style={{ fontSize: 12, color: fc.muted, marginTop: 6, lineHeight: '16px' }}>
              Try a different city, language, or specialty — or send a private invite by email instead.
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function SearchResultCard({ c, onClick }) {
  return (
    <div onClick={onClick} style={{
      background: '#fff', border: `1px solid ${fc.line}`,
      borderRadius: 16, padding: 14, marginBottom: 8,
      display: 'flex', gap: 12, alignItems: 'flex-start',
      cursor: 'pointer',
    }}>
      <PhotoTile tones={c.photoTone} initials={c.initials} size={54} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
          <span style={{
            fontSize: 14.5, fontWeight: 600, color: fc.ink, letterSpacing: -0.1,
          }}>{c.name}</span>
          {c.verified && <VerifiedTag small />}
        </div>
        <div style={{ fontSize: 11.5, color: fc.muted, marginTop: 2 }}>
          {c.title} · {c.yearsExp} yrs experience
        </div>
        <div style={{
          marginTop: 6, display: 'flex', alignItems: 'center', gap: 4,
          fontSize: 11, color: fc.muted,
        }}>
          {FCI.pin(fc.mutedSoft)}
          <span>{c.region}, {c.city} · {c.province}</span>
        </div>
        <div style={{
          marginTop: 8, display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <Stars rating={c.rating} />
            <span style={{ fontSize: 11, color: fc.ink, fontWeight: 600, marginLeft: 2 }}>
              {c.rating.toFixed(1)}
            </span>
            <span style={{ fontSize: 10.5, color: fc.mutedSoft }}>({c.reviewCount})</span>
          </div>
          <span style={{ color: fc.line }}>·</span>
          <span style={{ fontSize: 11, color: fc.forest, fontWeight: 600 }}>{c.rate}</span>
        </div>
      </div>
      <div style={{ alignSelf: 'center' }}>{FCI.chevR()}</div>
    </div>
  );
}

// =========================================================
// SCREEN 2 — Caregiver profile + send request
// =========================================================
function CaregiverProfile({ c, onBack, onSent }) {
  const [sending, setSending] = React.useState(false);
  const [sent, setSent] = React.useState(false);

  const sendRequest = () => {
    setSending(true);
    setTimeout(() => {
      setSending(false);
      setSent(true);
    }, 800);
  };

  return (
    <div style={{
      width: '100%', height: '100%', background: fc.cream,
      fontFamily: fc.sans, color: fc.ink,
      display: 'flex', flexDirection: 'column', paddingTop: 56,
      position: 'relative',
    }}>
      {/* top bar */}
      <div style={{
        padding: '14px 24px 0',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div onClick={onBack} style={{
          width: 36, height: 36, borderRadius: 12,
          background: '#fff', border: `1px solid ${fc.line}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer',
        }}>{FCI.back()}</div>
        <div style={{
          fontFamily: fc.serif, fontSize: 16, color: fc.forestDeep,
          fontWeight: 500, letterSpacing: -0.2,
        }}>Caregiver</div>
        <div style={{
          width: 36, height: 36, borderRadius: 12,
          background: '#fff', border: `1px solid ${fc.line}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{FCI.bookmark()}</div>
      </div>

      <div style={{ flex: 1, overflow: 'auto', paddingBottom: 110 }}>
        {/* hero */}
        <div style={{ padding: '24px 24px 0', display: 'flex', gap: 16, alignItems: 'flex-start' }}>
          <PhotoTile tones={c.photoTone} initials={c.initials} size={92} radius={20} />
          <div style={{ flex: 1, minWidth: 0, paddingTop: 4 }}>
            <div style={{
              fontFamily: fc.serif, fontSize: 22, lineHeight: '26px',
              color: fc.forestDeep, fontWeight: 500, letterSpacing: -0.4,
            }}>{c.name}</div>
            <div style={{
              fontSize: 12.5, color: fc.muted, marginTop: 4, lineHeight: '17px',
            }}>{c.title}</div>
            <div style={{
              marginTop: 8, display: 'flex', alignItems: 'center', gap: 4,
              fontSize: 11.5, color: fc.muted,
            }}>
              {FCI.pin(fc.mutedSoft)}
              <span>{c.region}, {c.city} · {c.province}, {c.country}</span>
            </div>
            {c.verified && (
              <div style={{ marginTop: 10 }}><VerifiedTag /></div>
            )}
          </div>
        </div>

        {/* stat strip */}
        <div style={{
          padding: '20px 20px 0', display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8,
        }}>
          <StatTile big={`${c.yearsExp}`} label="Years exp." />
          <StatTile big={c.rating.toFixed(1)} label={`${c.reviewCount} reviews`} stars />
          <StatTile big={c.rate} label="Rate" />
        </div>

        {/* bio */}
        <div style={{ padding: '22px 24px 0' }}>
          <SectionTitle title="About" />
          <div style={{ fontSize: 13, color: fc.ink, lineHeight: '19px', letterSpacing: -0.05 }}>
            {c.bio}
          </div>
        </div>

        {/* specialties */}
        <div style={{ padding: '22px 24px 0' }}>
          <SectionTitle title="Specialties" />
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            {c.specialties.map((s, i) => (
              <span key={i} style={{
                padding: '5px 11px', borderRadius: 99,
                background: '#fff', border: `1px solid ${fc.line}`,
                fontSize: 12, color: fc.ink, fontWeight: 500, letterSpacing: -0.1,
              }}>{s}</span>
            ))}
          </div>
        </div>

        {/* languages + availability */}
        <div style={{ padding: '22px 20px 0', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <InfoCard label="Languages" value={c.languages.join(' · ')} />
          <InfoCard label="Available" value={c.available} />
        </div>

        {/* location card */}
        <div style={{ padding: '20px 20px 0' }}>
          <div style={{
            background: '#fff', borderRadius: 16, border: `1px solid ${fc.line}`,
            padding: 14, display: 'flex', gap: 12, alignItems: 'center',
          }}>
            <div style={{
              width: 56, height: 56, borderRadius: 12, flexShrink: 0,
              background: `linear-gradient(135deg, ${fc.sageSoft} 0%, ${fc.cream} 100%)`,
              border: `1px solid ${fc.lineSoft}`,
              position: 'relative', overflow: 'hidden',
            }}>
              {/* faux map lines */}
              <svg width="56" height="56" viewBox="0 0 56 56" style={{ position: 'absolute', inset: 0, opacity: 0.5 }}>
                <path d="M0 20 Q15 18 30 24 T56 22" stroke={fc.sage} strokeWidth="1" fill="none"/>
                <path d="M0 38 Q20 36 35 40 T56 38" stroke={fc.sage} strokeWidth="1" fill="none"/>
                <path d="M14 0 L18 56" stroke={fc.sage} strokeWidth="0.8" fill="none" opacity="0.7"/>
                <path d="M38 0 L42 56" stroke={fc.sage} strokeWidth="0.8" fill="none" opacity="0.7"/>
              </svg>
              <div style={{
                position: 'absolute', top: '50%', left: '50%',
                transform: 'translate(-50%, -100%)',
              }}>
                <svg width="14" height="18" viewBox="0 0 14 18">
                  <path d="M7 1a6 6 0 016 6c0 4.5-6 10-6 10s-6-5.5-6-10a6 6 0 016-6z" fill={fc.terracotta}/>
                  <circle cx="7" cy="7" r="2" fill="#fff"/>
                </svg>
              </div>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 11, color: fc.muted, letterSpacing: 0.4, textTransform: 'uppercase', fontWeight: 600 }}>Location</div>
              <div style={{ fontFamily: fc.serif, fontSize: 15, color: fc.forestDeep, fontWeight: 500, marginTop: 2, letterSpacing: -0.2 }}>
                {c.region}, {c.city}
              </div>
              <div style={{ fontSize: 11.5, color: fc.muted, marginTop: 1 }}>
                {c.province} · {c.country}
              </div>
            </div>
          </div>
        </div>

        {/* reviews */}
        <div style={{ padding: '24px 24px 0' }}>
          <SectionTitle title="Reviews" count={c.reviewCount} accent={`★ ${c.rating.toFixed(1)} average`} />
          <div style={{
            background: '#fff', borderRadius: 16, border: `1px solid ${fc.line}`,
            overflow: 'hidden',
          }}>
            {c.reviews.length === 0 ? (
              <div style={{ padding: 18, fontSize: 12.5, color: fc.muted, textAlign: 'center' }}>
                No reviews yet.
              </div>
            ) : c.reviews.map((r, i) => (
              <ReviewRow key={i} r={r} isLast={i === c.reviews.length - 1} />
            ))}
          </div>
        </div>
      </div>

      {/* sticky CTA */}
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0,
        background: `linear-gradient(to top, ${fc.cream} 60%, rgba(246,241,234,0))`,
        padding: '16px 20px 26px',
      }}>
        <div style={{ display: 'flex', gap: 10 }}>
          <button style={{
            width: 54, height: 54, borderRadius: 16,
            background: '#fff', border: `1px solid ${fc.line}`,
            cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>{FCI.msg()}</button>
          <button onClick={sendRequest} disabled={sent || sending} style={{
            flex: 1, height: 54, borderRadius: 16, border: 'none',
            background: sent ? fc.sage : fc.forestDeep,
            color: '#fff', fontFamily: fc.sans,
            fontSize: 15, fontWeight: 600, letterSpacing: -0.1,
            cursor: sent ? 'default' : 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            opacity: sending ? 0.7 : 1,
            transition: 'background .2s',
          }}>
            {sent ? (
              <React.Fragment>
                <svg width="14" height="11" viewBox="0 0 14 11"><path d="M1 6L5 10L13 1" stroke="#fff" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
                Request sent
              </React.Fragment>
            ) : sending ? (
              'Sending…'
            ) : (
              <React.Fragment>
                Send request {FCI.send()}
              </React.Fragment>
            )}
          </button>
        </div>
        {!sent && (
          <div style={{
            marginTop: 10, textAlign: 'center', fontSize: 11, color: fc.mutedSoft,
            letterSpacing: 0.1,
          }}>
            {c.name.split(' ')[0]} sees your name and the role you'd like to fill. No data is shared until they accept.
          </div>
        )}
        {sent && (
          <div style={{
            marginTop: 10, textAlign: 'center', fontSize: 11.5, color: fc.muted,
          }}>
            You'll be notified when {c.name.split(' ')[0]} responds. Usually within 24 hours.
          </div>
        )}
      </div>
    </div>
  );
}

function StatTile({ big, label, stars }) {
  return (
    <div style={{
      background: '#fff', borderRadius: 14, border: `1px solid ${fc.line}`,
      padding: '12px 12px',
    }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
        <span style={{
          fontFamily: fc.serif, fontSize: 22, color: fc.forestDeep,
          fontWeight: 500, letterSpacing: -0.4, lineHeight: 1,
        }}>{big}</span>
        {stars && (
          <svg width="11" height="11" viewBox="0 0 11 11">
            <path d="M5.5 1l1.4 2.8 3.1.5-2.3 2.2.5 3.1L5.5 8.1 2.8 9.6l.5-3.1L1 4.3l3.1-.5L5.5 1z" fill="#D49542"/>
          </svg>
        )}
      </div>
      <div style={{ fontSize: 10, color: fc.muted, letterSpacing: 0.4, textTransform: 'uppercase', marginTop: 4 }}>{label}</div>
    </div>
  );
}

function InfoCard({ label, value }) {
  return (
    <div style={{
      background: '#fff', borderRadius: 14, border: `1px solid ${fc.line}`,
      padding: '12px 14px',
    }}>
      <div style={{ fontSize: 10, color: fc.muted, letterSpacing: 0.4, textTransform: 'uppercase', fontWeight: 600 }}>{label}</div>
      <div style={{ fontSize: 13, color: fc.ink, marginTop: 3, fontWeight: 500, letterSpacing: -0.1, lineHeight: '17px' }}>{value}</div>
    </div>
  );
}

function ReviewRow({ r, isLast }) {
  return (
    <div style={{
      padding: '14px 16px',
      borderBottom: isLast ? 'none' : `1px solid ${fc.lineSoft}`,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <div style={{
          width: 26, height: 26, borderRadius: 99,
          background: fc.cream, border: `1px solid ${fc.line}`,
          color: fc.muted, fontFamily: fc.serif, fontSize: 11, fontWeight: 500,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{r.who.split(' ').map(w => w[0]).join('').slice(0, 2)}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12.5, fontWeight: 600, color: fc.ink, letterSpacing: -0.1 }}>{r.who}</div>
          <div style={{ fontSize: 10.5, color: fc.mutedSoft }}>{r.rel}</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <Stars rating={r.stars} size={9} />
        </div>
      </div>
      <div style={{
        marginTop: 8, fontSize: 12.5, color: fc.ink, lineHeight: '17px',
        letterSpacing: -0.05, textWrap: 'pretty',
      }}>"{r.text}"</div>
      <div style={{ marginTop: 6, fontSize: 10, color: fc.mutedSoft, letterSpacing: 0.3 }}>{r.when}</div>
    </div>
  );
}

function SectionTitle({ title, count, accent }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
      marginBottom: 10,
    }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
        <span style={{
          fontFamily: fc.serif, fontSize: 16, color: fc.forestDeep,
          fontWeight: 500, letterSpacing: -0.3,
        }}>{title}</span>
        {count != null && (
          <span style={{
            fontSize: 11, fontFamily: 'ui-monospace, monospace',
            color: fc.muted, letterSpacing: 0.4,
          }}>{String(count).padStart(2, '0')}</span>
        )}
      </div>
      {accent && (
        <span style={{ fontSize: 11, color: fc.muted, letterSpacing: 0.2 }}>{accent}</span>
      )}
    </div>
  );
}

// =========================================================
// Find-caregiver flow wrapper
// =========================================================
function FindCaregiverFlow({ onBack, initialProfile }) {
  const [view, setView] = React.useState(initialProfile ? 'profile' : 'search');
  const [selected, setSelected] = React.useState(initialProfile || null);

  if (view === 'profile' && selected) {
    return <CaregiverProfile
      c={selected}
      onBack={() => { setView('search'); setSelected(null); }}
    />;
  }
  return <FindCaregiverSearch onBack={onBack} onOpenProfile={(c) => { setSelected(c); setView('profile'); }} />;
}

Object.assign(window, {
  FindCaregiverSearch, CaregiverProfile, FindCaregiverFlow,
  caregiverDirectory,
});
